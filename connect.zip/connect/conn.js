var mongoose=require("mongoose");

mongoose.connect("mongodb://localhost:27017/inventorymanage").then((e)=>{
    console.log("connected to DateBase....");
}).catch((e)=>{
     console.log("error something went wrong .....pls check the connections..."+e);
});
